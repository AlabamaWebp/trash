Identify expected behavior, observed behavior, and the smallest useful reproduction. Use the error and relevant code to choose a testable hypothesis.
Run a targeted check that distinguishes likely causes. Change the confirmed cause, preserving unrelated behavior. After a failed attempt, use new evidence rather than repeating the same action.
Verify the fix with a reproduction or regression test when feasible. State the cause, actual verification, and remaining uncertainty.
