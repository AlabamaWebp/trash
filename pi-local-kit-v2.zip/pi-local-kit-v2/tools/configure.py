#!/usr/bin/env python3
"""Apply a local Pi profile; dry-run by default. No dependencies."""
import argparse, copy, datetime, json, os, shutil
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent

def load(p):
    if not p.exists(): return {}
    obj = json.loads(p.read_text(encoding='utf-8-sig'))
    if not isinstance(obj, dict): raise ValueError(f'{p}: expected JSON object')
    return obj

def merge(a,b):
    a=copy.deepcopy(a)
    for k,v in b.items():
        a[k]=merge(a[k],v) if isinstance(v,dict) and isinstance(a.get(k),dict) else copy.deepcopy(v)
    return a

def main():
    profiles=load(ROOT/'profiles/index.json')
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--profile',required=True,choices=profiles)
    ap.add_argument('--model',required=True,help='Exact server model ID')
    ap.add_argument('--url',default='http://127.0.0.1:8080/v1')
    ap.add_argument('--api-key',default='local',help='Prefer literal $ENV_NAME, not real secret')
    ap.add_argument('--reasoning',action='store_true')
    ap.add_argument('--thinking',choices=['off','low','medium','high'],default=None,help='Pi preference; server support must be verified')
    ap.add_argument('--mode',choices=['native','prune-only','context-kit'],default='native')
    ap.add_argument('--prompt',choices=['01-minimal','02-balanced','03-debug','04-long-task','05-read-only','08-reasoning','09-weak-tool-use','10-micro'])
    ap.add_argument('--agent-dir',type=Path,default=Path(os.environ.get('PI_CODING_AGENT_DIR') or Path.home()/'.pi/agent'))
    ap.add_argument('--apply',action='store_true')
    args=ap.parse_args()
    if not args.model.strip() or args.model=='REPLACE_WITH_SERVER_MODEL_ID': ap.error('Use the real model ID')
    if not args.url.startswith(('http://','https://')): ap.error('Use an http(s) endpoint')
    d=args.agent_dir.expanduser().resolve()
    p=ROOT/'profiles'/args.profile
    s=load(d/'settings.json'); m=load(d/'models.json')
    preset=load(p/f'settings.{args.mode}.json')
    comp=preset.pop('compaction'); kit=preset.pop('context-kit')
    s=merge(s,preset)
    if args.thinking is not None: s['defaultThinkingLevel']=args.thinking
    sc=s.setdefault('compaction',{}); sc['enabled']=True
    sc.setdefault('modelOverrides',{})['local/'+args.model]={k:comp[k] for k in ('reserveTokens','keepRecentTokens')}
    # Replace this extension block, not other settings; old advanced keys can invalidate it.
    s['context-kit']=kit
    s['defaultProvider']='local'; s['defaultModel']=args.model
    provider=load(p/'models.example.json')['providers']['local']
    entry=provider.pop('models')[0]; entry.update(id=args.model,name=args.model,reasoning=args.reasoning)
    provider.update(baseUrl=args.url.rstrip('/'),apiKey=args.api_key)
    dest=m.setdefault('providers',{}).setdefault('local',{})
    oldmodels=dest.get('models',[])
    if not isinstance(oldmodels,list): raise ValueError('local.models must be an array')
    if oldmodels and dest.get('baseUrl') and dest['baseUrl'].rstrip('/') != provider['baseUrl']:
        raise ValueError('Existing local provider has a different URL. Merge manually or use --agent-dir.')
    dest.update(provider)
    existing=next((x for x in oldmodels if x.get('id')==args.model),{})
    dest['models']=[x for x in oldmodels if x.get('id')!=args.model]+[merge(existing,entry)]
    changes={'settings.json':json.dumps(s,ensure_ascii=False,indent=2)+'\n','models.json':json.dumps(m,ensure_ascii=False,indent=2)+'\n'}
    if args.prompt:
        source=next((ROOT/'prompts'/args.prompt).glob('*.md'))
        changes[source.name]=source.read_text(encoding='utf-8')
        other='APPEND_SYSTEM.md' if source.name=='SYSTEM.md' else 'SYSTEM.md'
        if (d/other).exists(): changes[other]=None
    print('Agent directory:',d,'\nProfile:',args.profile,'Mode:',args.mode,'Model:',args.model)
    print('Changes:',', '.join(k+(' (remove after backup)' if v is None else '') for k,v in changes.items()))
    if not args.apply:
        print('Dry run. No files changed. Close Pi and Pi Web before running with --apply.'); return
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    backup=d/'backups'/stamp; backup.mkdir(parents=True)
    manifest={}
    for name in changes:
        target=d/name; manifest[name]=target.exists()
        if target.exists(): shutil.copy2(target,backup/name)
    (backup/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    for name,content in changes.items():
        target=d/name
        if content is None: target.unlink(missing_ok=True); continue
        temp=d/('.'+name+'.'+stamp+'.tmp')
        temp.write_text(content,encoding='utf-8')
        if target.exists(): shutil.copymode(target,temp)
        else: temp.chmod(0o600)
        temp.replace(target)
    print('Applied. Backup:',backup,'\nRestart Pi and Pi Web.')

if __name__=='__main__': main()
