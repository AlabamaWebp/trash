# 1. Установка (Ubuntu / Windows)

Pi запускай на машине, где лежит рабочий проект. llama.cpp может быть на другой машине. Pi Web работает с локальной файловой системой машины, на которой запущен. Не открывай его порт наружу.

## Node.js
Требование Pi Web: Node >=22.19.0. Рекомендуемый вариант Node 24 LTS, также нужен Git. Ubuntu: если установлен nvm (https://github.com/nvm-sh/nvm), `nvm install 24 && nvm use 24`. Иначе установи nvm по README или Node с https://nodejs.org/. Windows PowerShell: `winget install OpenJS.NodeJS.LTS` и `winget install Git.Git`, если их нет; открой новое окно. Проверка:

```sh
node --version
npm --version
git --version
```

## CLI и GUI
```sh
npm install -g @earendil-works/pi-coding-agent
npm install -g @agegr/pi-web@latest
pi --version
pi-web version
```
На Windows, если политика PowerShell блокирует npm.ps1, используй `npm.cmd`, `pi.cmd`, `pi-web.cmd` вместо отключения защиты. На Ubuntu не ставь npm-пакеты через sudo при использовании nvm.

После настройки модели и профиля (`02-llama`, `03-profiles`):
```sh
pi
```
В CLI `/model`, выбери модель. Выполни тест. Выйди, затем:
```sh
pi-web
```
Открой http://127.0.0.1:30141. Выбери папку проекта и модель, создай сессию. Pi Web использует общую директорию агента (если не задана другая). Не веди одну сессию одновременно из двух интерфейсов. Для применения изменений перезапусти Pi Web: `pi-web stop`, `pi-web`.

## Плагины — только при необходимости
Для обычного одиночного llama-server с OpenAI API плагины не нужны. Pi Web — отдельный npm-пакет, не расширение агента. В актуальном Pi также есть встроенная интеграция router llama.cpp (`/llama`, см. docs моделей).

Если требуется автоматическое обнаружение нескольких серверов или llama-swap, после ознакомления с исходниками:
```sh
pi install npm:pi-llama-cpp
pi list
```
Настрой адрес по `examples/llama-extension.settings.json`. В терминале Pi `/models servers`, затем `/model`. Не дублируй один сервер одновременно через models.json и расширение, если не сравниваешь их специально.

Для A/B эксперимента с очисткой контекста:
```sh
pi install npm:pi-context-kit
pi list
```
Примени `settings.context-kit.json` нужного профиля. В CLI `/context-kit` показывает состояние; у GUI поддержка интерактивных панелей может отличаться. Начинай тест в CLI. Удаление: `pi remove npm:pi-context-kit` или `pi remove npm:pi-llama-cpp`; перезапусти оба интерфейса. Для baseline можно просто удалить Context Kit (иначе recall может оставаться доступным даже при enabled:false).

Пакеты выполняют код с правами пользователя. Проверь репозитории до установки, не устанавливай непроверенные наборы расширений. Не добавляй MCP, skills и субагентов на старте. Сохрани версии `pi --version`, `pi-web version`, `pi list`; если GUI ломается после обновления, сверяй релизы Pi Web: он поставляет собственную версию Pi SDK и может отличаться от глобального CLI. Для воспроизведения используй подтверждённые номера через npm install -g package@version, а не слепое обновление.

Если нужен GUI с другого ПК, предпочтительнее SSH-туннель: `ssh -L 30141:127.0.0.1:30141 user@host` и открыть localhost. Pi Web оставь на loopback. Не публикуй агент в интернет.

## Версия Context Kit для воспроизводимости
На дату обновления страница пакета указывает 0.4.6 (19.11.2026). Перед использованием проверь текущую версию и её README. Для эксперимента сначала native, затем `settings.prune-only.json`, затем при необходимости `settings.context-kit.json`. Не устанавливай отдельный purging-пакет только ради сокращения промпта: SYSTEM/APPEND уже позволяют проверить этот вариант.
