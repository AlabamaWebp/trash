# Источники и ограничения
Проверено по опубликованной документации 25.11.2026. Ссылки на живые ветки могут меняться.
- Pi settings: https://github.com/earendil-works/pi/blob/main/packages/coding-agent/docs/settings.md
- Pi configuration: https://github.com/earendil-works/pi/blob/main/packages/coding-agent/docs/configuration.md
- Pi models: https://github.com/earendil-works/pi/blob/main/packages/coding-agent/docs/models.md
- Pi compaction: https://github.com/earendil-works/pi/blob/main/packages/coding-agent/docs/compaction.md
- Pi CLI: https://github.com/earendil-works/pi/blob/main/packages/coding-agent/docs/cli.md
- Pi Web: https://github.com/agegr/pi-web/blob/main/docs/README.ru.md
- Pi Web releases: https://github.com/agegr/pi-web/releases
- Context Kit: https://pi.dev/packages/pi-context-kit
- llama.cpp extension: https://github.com/gsanhueza/pi-llama-cpp
- llama.cpp server: https://github.com/ggml-org/llama.cpp/blob/master/tools/server/README.md

Промпты и численные профили написаны для данного набора, не копируют готовые промпты других проектов и не имеют подтверждённого преимущества на бенчмарке. Проверяется синтаксис JSON, арифметика профилей и работа скрипта на временных файлах. Установка npm, реальный инференс, совместимость конкретных версий GUI и расширений не проверены в этом окружении. Не включены модели, зависимости, ключи или исполняемые бинарники.

## Исследовательское обновление
См. `07-research-2026.md` — официальные руководства OpenAI, Anthropic, Google, Qwen и сопоставление с конкретными правками. Pi configuration и compaction теперь также проверены по https://docs.pi.dev/latest/configuration и https://docs.pi.dev/latest/compaction. Context Kit 0.4.6 (19.11.2026) — версия документации при проверке.
