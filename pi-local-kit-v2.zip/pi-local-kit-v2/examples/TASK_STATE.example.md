# Goal
<one sentence>
# Constraints / acceptance criteria
- <fact>
# Decisions and evidence
- <decision + reason or path>
# Changed paths
- <path + effect>
# Checks
- <command + actual result>
# Next action / blocker
<one concrete next step>
