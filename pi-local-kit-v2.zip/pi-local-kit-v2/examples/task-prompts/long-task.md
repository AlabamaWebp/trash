# Goal
<Outcome>
# Constraints
<Scope, compatibility, permissions>
# Acceptance criteria
<Observable results and checks>
# Checkpoint
You may maintain a short local TASK_STATE.md for this task; update it after milestones and on handoff. Do not store secrets. Continue until the criteria are satisfied or a concrete blocker remains.
