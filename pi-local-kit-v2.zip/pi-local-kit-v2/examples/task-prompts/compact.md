In the Pi CLI, use:

/compact Preserve the user's exact acceptance criteria, constraints, confirmed decisions, changed paths, current errors, checks run with outcomes, and next action. Drop redundant logs and superseded reads. Mark unknowns explicitly.

This is a manual compaction instruction, not a system prompt. Check the actual summary before trusting it. It still uses an LLM.
