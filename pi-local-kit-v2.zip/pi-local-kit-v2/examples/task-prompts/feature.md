# Goal
<Observable behavior the user wants>

# Constraints
<Existing APIs, paths, compatibility, scope>

# Acceptance criteria
- <Observable check 1>
- <Observable check 2>

Implement and verify. If a missing decision changes public behavior or creates risk, ask; otherwise use a reasonable reversible assumption.
