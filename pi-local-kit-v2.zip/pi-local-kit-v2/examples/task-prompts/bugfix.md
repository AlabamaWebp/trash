# Expected
<Expected behavior>
# Actual
<Observed behavior and relevant error>
# Reproduction
<Smallest reproducible example, command, or file>
# Done when
<Regression check and preserved behavior>
Fix the cause, not just the symptom. Report actual verification.
