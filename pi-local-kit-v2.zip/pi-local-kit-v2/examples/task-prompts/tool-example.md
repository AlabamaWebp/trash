# Optional example for a model with poor tool selection
Use as part of a task prompt only when A/B demonstrates a need. Do not append to all sessions.

Task: change a known setting in `src/config.ts`.
Desired behavior: use the declared read tool for the relevant part; use the declared edit tool for the exact change; use an appropriate local test/check; report what happened. If the edit fails, read the current relevant range and adjust the edit. Use the actual tool schema from the runtime, not this prose as a JSON schema.
