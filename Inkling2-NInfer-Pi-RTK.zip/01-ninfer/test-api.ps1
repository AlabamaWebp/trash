$ErrorActionPreference = 'Stop'
$base = 'http://127.0.0.1:8080/v1'
Invoke-RestMethod "$base/models" | ConvertTo-Json -Depth 8
$body = @{model='inkling-2-mini';messages=@(@{role='user';content='Reply with the word OK.'});max_tokens=128;stream=$false} | ConvertTo-Json -Depth 6
Invoke-RestMethod "$base/chat/completions" -Method Post -ContentType 'application/json' -Body $body | ConvertTo-Json -Depth 12
