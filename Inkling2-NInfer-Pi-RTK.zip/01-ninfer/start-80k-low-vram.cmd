@echo off
setlocal
cd /d "%~dp0"
if not exist "runtime\ninfer-serve.exe" (
  echo ERROR: Extract native NInfer release to runtime folder.
  pause
  exit /b 1
)
if not exist "models\Inkling-2-Mini-UD-IQ4_XS-ninfer-v3.ninfer" (
  echo ERROR: Model artifact not found in models folder.
  pause
  exit /b 1
)
"runtime\ninfer-serve.exe" --config "inkling-80k-low-vram.ini"
if errorlevel 1 pause
