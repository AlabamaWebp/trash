# NInfer-all (Windows)

1. Обновите драйвер NVIDIA. Скачайте Windows x64 native release с https://github.com/iamwavecut/ninfer-all/releases (не архив исходников). Распакуйте **все** файлы в `runtime/` рядом с этим README, чтобы `runtime/ninfer-serve.exe` существовал. Для Ampere подходит CUDA 12.9 или 13.4 при совместимом драйвере; портативная сборка выбирает backend сама. Отдельный CUDA Toolkit не нужен.
2. Если `hf` ещё нет, в PowerShell: `py -m pip install -U huggingface_hub`. Перезапустите терминал, запустите `download-model.cmd`. Или скачайте файл вручную: https://huggingface.co/WaveCut/Inkling-2-Mini-UD-IQ4_XS-NInfer-v3 и положите его в `models/`. Нужны примерно 17–18 ГБ свободного места для весов.
3. Закройте приложения, занимающие VRAM. Запустите `start-80k.cmd`. Дождитесь сообщения о готовности HTTP-сервера. В другом PowerShell из этой папки: `powershell -NoProfile -File .\test-api.ps1` (либо выполните команды из файла вручную, если политика исполнения запрещает скрипты).
4. Если всё работает, подключите Pi. `nvidia-smi` показывает VRAM; в логах NInfer смотрите prefill/decode, cache hit и TTFT.

## Профили

| Файл | Контекст | KV | Loop KV | Назначение |
|---|---:|---|---|---|
| inkling-80k.ini | 81920 | rk4v4 | per-pass | основной, сохраняет раздельные проходы |
| inkling-80k-low-vram.ini | 81920 | rk4v4 | last-full | экономия KV с компромиссом качества |
| inkling-32k.ini | 32768 | rk4v4 | per-pass | если 80k не стартует |

У всех: host experts, auto expert cache, одна последовательность, без спекулятивного декодирования. Vision не запрашивается. Отдельные настройки prefix cache оставлены штатными; не отключайте reuse без причины. Если нужен другой GPU, задайте CUDA_VISIBLE_DEVICES перед стартом, предварительно сверив GPU в `nvidia-smi`.

## Нехватка памяти
- При ошибке выделения VRAM сначала запустите `start-80k-low-vram.cmd`. Если не помогло, можно попробовать ограничить `expert-cache-mib = 256` вместо auto, сверив ошибку и повторно протестировав. Это может замедлить генерацию. 80k на конкретной RTX 3050 не подтверждены замером; официальный host-профиль использует 32k, а опубликованный 8-ГБ тест проводился с 12k.
- Если не хватает закреплённой RAM, закройте приложения; 32 ГБ рекомендуются. При 16 ГБ RAM рассмотрите меньший артефакт UD-Q3_K_XL (измените имя модели в INI и скачайте соответствующий файл) либо `expert-residency = disk` на SSD, с потерей скорости. Скрипты запуска проверяют имя IQ4_XS — при смене файла измените проверку или запустите `runtime\ninfer-serve.exe --config inkling-80k.ini` непосредственно.
- Если сервер не стартует и с резервным 80k, попробуйте `start-32k.cmd`. Обязательно используйте альтернативный `02-pi/models-32k.json` и `settings-32k.json`.
- Если опция неизвестна, скачайте свежий релиз и проверьте `runtime\ninfer-serve.exe --help`; флаги меняются. При ошибке API сначала проверьте `/v1/models` и простой запрос; ID должен быть `inkling-2-mini`.

Документация: https://github.com/iamwavecut/ninfer-all/blob/master/docs/inkling2.md ; https://github.com/iamwavecut/ninfer-all/blob/master/configs/inkling2-mini-host.ini ; https://github.com/iamwavecut/ninfer-all/blob/master/docs/serving.md
