@echo off
setlocal
cd /d "%~dp0"
where hf >nul 2>nul || (echo Install huggingface_hub and reopen terminal. & exit /b 1)
hf download WaveCut/Inkling-2-Mini-UD-IQ4_XS-NInfer-v3 Inkling-2-Mini-UD-IQ4_XS-ninfer-v3.ninfer --local-dir models
