# RTK (Rust Token Killer) для Pi

Рекомендуемый вариант — штатное расширение Pi, которое переписывает подходящие shell-команды через RTK. Оно уменьшает объём вывода инструментов, не меняет веса или KV-кэш и не требует отдельного API-прокси.

## Установка на Windows
В PowerShell:
```powershell
winget install --id rtk-ai.rtk -e
winget install --id BurntSushi.ripgrep.MSVC -e
```
Если winget недоступен: https://github.com/rtk-ai/rtk/releases — скачайте `rtk-x86_64-pc-windows-msvc.zip`, распакуйте и добавьте папку с `rtk.exe` в PATH. Перезапустите терминал и выполните:
```powershell
rtk --version
rtk gain
rtk init --agent pi --global
```
Последняя команда создаст `~/.pi/agent/extensions/rtk.ts` (или в `PI_CODING_AGENT_DIR`). Перезапустите Pi. Для установки только в одном проекте используйте `rtk init --agent pi` из его корня вместо глобального варианта. Не устанавливайте оба сразу без необходимости.

## Проверка
```powershell
rtk git status
rtk gain
```
Затем в Pi попросите агента запустить `git status`, `git diff` и тесты проекта. После этого снова вызовите `rtk gain`. Сжатие зависит от команды; оно не сокращает каждый запрос на одинаковый процент. Если пропала важная диагностика, повторите команду без фильтра (`rtk proxy git diff` — проверить поддержку через `rtk proxy --help`) либо временно отключите расширение.

Удаление глобальной интеграции:
```powershell
rtk init --uninstall --agent pi --global
```
Для локальной установки уберите `--global` и выполняйте из корня проекта.

## RTK Proxy (отдельный необязательный компонент)
Не путать `rtk proxy <command>` (сырой вывод команды) и `rtk llm-proxy` (HTTP daemon). По документации на 26.11.2026 автоматический проверенный запуск HTTP proxy описан для Claude Code; связка Pi → RTK HTTP proxy → NInfer не подтверждена. Поэтому не перенаправляйте baseUrl из готового Pi-конфига на proxy. Обычная RTK-интеграция уже полезна и не вмешивается в API.

Если хотите исследовать HTTP proxy отдельно, скачайте подходящий `rtk-proxy-<target>` из того же релиза и положите рядом с rtk.exe. Команды диагностики:
```powershell
rtk llm-proxy setup
rtk llm-proxy start --bind 127.0.0.1:9090
rtk llm-proxy status --bind 127.0.0.1:9090
rtk llm-proxy stats --bind 127.0.0.1:9090
rtk llm-proxy stop --bind 127.0.0.1:9090
```
Порт 9090 выбран, чтобы не конфликтовать с NInfer на 8080. Эти команды не настраивают Pi и не гарантируют совместимость upstream. Для автономного локального агента оставьте Pi напрямую на NInfer, а RTK — в роли shell-оптимизатора.

Документация: https://www.rtk-ai.app/docs/getting-started/installation/ ; https://www.rtk-ai.app/docs/getting-started/supported-agents/ ; https://www.rtk-ai.app/docs/proxy/overview/
