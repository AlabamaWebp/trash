# Pi — подключение NInfer

1. Если Pi не установлен: установите актуальный Node.js LTS и пакет Pi по https://pi.dev/ (см. установку для вашей версии). Если `pi --version` работает, переустановка не нужна.
2. В PowerShell: `New-Item -ItemType Directory -Force "$HOME/.pi/agent"`. Если задан `PI_CODING_AGENT_DIR`, используйте его вместо этого пути.
3. Если файлов ещё нет, скопируйте `models.json` и `settings.json` из этой папки в каталог агента. Если они уже существуют, **не заменяйте их целиком**: сделайте копии и добавьте `providers.ninfer` из models.json, а из settings.json — `defaultProvider`, `defaultModel` (если хотите Inkling по умолчанию) и `compaction.modelOverrides` для `ninfer/inkling-2-mini`. Сохраните прочие настройки и провайдеры. Проверьте, что нет конфликта с уже существующим ключом ninfer.
4. Запустите сервер NInfer, затем в папке проекта `pi --provider ninfer --model inkling-2-mini`. Или выберите модель через `/model` в Pi.
5. Для проверки попросите Pi прочитать README проекта и запустить `git status`. Проверьте, что инструмент вызвался, а модель продолжила работу после результата. При ошибке проверьте лог NInfer и `01-ninfer/test-api.ps1`.

## Настройки основного профиля
- 81920 токенов физического окна; до 8192 токенов ответа, включая внутреннее рассуждение, если сервер его выдаёт.
- Компактизация примерно после 61440 токенов (81920 − 20480), сохраняет около 20000 последних токенов плюс резюме. Итоговый размер не фиксирован. `/compact` — вручную. Резерв не является лимитом ответа.
- `reasoning: false` отключает управление thinking со стороны Pi; не гарантирует, что сама Inkling перестанет рассуждать. Это совместимый стартовый режим для локального OpenAI Chat Completions API.
- `apiKey: local` — фиктивное значение для локального API, не секрет.
- Если получаете обрезанный ответ, сначала проверьте `finish_reason` и лимит 8192; при необходимости увеличьте `maxTokens` до 12288 или 16384, сохраняя достаточный резерв. Не увеличивайте `contextWindow` сверх серверного.
- Если запустили 32k-профиль NInfer, используйте содержимое `models-32k.json` и `settings-32k.json` под обычными именами `models.json` / `settings.json`. Не держите два одинаковых ID в одном провайдере.
- Pi с несколькими агентами не ускорит один GPU; начните с одной сессии.

Документация: https://github.com/earendil-works/pi/blob/main/packages/coding-agent/docs/models-configuration.md ; https://github.com/earendil-works/pi/blob/main/packages/coding-agent/docs/compaction.md ; https://github.com/earendil-works/pi/blob/main/packages/coding-agent/docs/settings.md
