import fs from "node:fs";

const file = process.argv[2];
if (!file) {
  console.error("Usage: node diagnostics.mjs <log-file>");
  process.exit(2);
}

const text = fs.readFileSync(file, "utf8");
const lines = text.split(/\r?\n/);
const seen = new Set();
const selected = [];

for (const line of lines) {
  if (!/\b(?:TS\d{4,5}|NG\d{4,5}|ERROR|FAIL|FAILED)\b/i.test(line) &&
      !/\.tsx?\(\d+,\d+\):\s*error/i.test(line)) continue;

  const normalized = line.trim().replace(/\s+/g, " ");
  if (!normalized || seen.has(normalized)) continue;
  seen.add(normalized);
  selected.push(normalized.slice(0, 600));
  if (selected.length >= 60) break;
}

console.log(selected.length ? selected.join("\n") : "No matching diagnostics");
if (selected.length >= 60) console.log("... diagnostics capped");
