import fs from "node:fs";
import { spawn } from "node:child_process";

const label = process.argv[2];
let command = process.argv.slice(3);
if (command[0] === "--") command.shift();

if (!label || !/^[a-zA-Z0-9_-]+$/.test(label) || !command.length) {
  console.error("Usage: measure.mjs <label> -- <command> [args...]");
  process.exit(2);
}

const executable = process.platform === "win32" && command[0] === "npx"
  ? "npx.cmd" : command[0];

const start = process.hrtime.bigint();
const child = spawn(executable, command.slice(1), { stdio: "inherit" });
let spawnError = false;

child.on("error", error => {
  spawnError = true;
  console.error(error.message);
});

child.on("close", code => {
  const ms = Number(process.hrtime.bigint() - start) / 1e6;
  const exit = spawnError ? 127 : (code ?? 1);
  fs.mkdirSync(".agent", { recursive: true });
  const file = ".agent/metrics.csv";
  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, "timestamp,label,exit_code,duration_ms\n");
  }
  fs.appendFileSync(file, [
    new Date().toISOString(), label, exit, ms.toFixed(1)
  ].join(",") + "\n");
  console.log("Recorded:", label, ms.toFixed(1) + "ms", "exit=" + exit);
  process.exitCode = exit;
});
