import fs from "node:fs";

const file = process.argv[2] || ".agent/metrics.csv";
if (!fs.existsSync(file)) {
  console.error("Metrics file not found:", file);
  process.exit(2);
}

const lines = fs.readFileSync(file, "utf8").trim().split(/\r?\n/).slice(1);
const groups = new Map();

for (const line of lines) {
  const [timestamp, label, code, ms] = line.split(",");
  if (!label || !Number.isFinite(Number(ms))) continue;
  const item = groups.get(label) || { count: 0, passed: 0, total: 0 };
  item.count++;
  if (Number(code) === 0) item.passed++;
  item.total += Number(ms);
  groups.set(label, item);
}

for (const [label, item] of groups) {
  console.log(
    label,
    "runs=" + item.count,
    "pass=" + (100 * item.passed / item.count).toFixed(1) + "%",
    "avg=" + (item.total / item.count).toFixed(1) + "ms"
  );
}
