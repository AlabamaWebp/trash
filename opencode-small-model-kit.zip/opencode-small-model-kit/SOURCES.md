# Официальные источники

Документация OpenCode:
- https://opencode.ai/docs/config
- https://opencode.ai/docs/agents
- https://opencode.ai/docs/tools
- https://opencode.ai/docs/models
- https://opencode.ai/docs/providers
- https://opencode.ai/docs/permissions
- https://opencode.ai/docs/compaction
- https://opencode.ai/docs/mcp

Дополнительные источники:
- https://github.com/ggml-org/llama.cpp
- https://github.com/microsoft/TypeScript
- https://github.com/BurntSushi/ripgrep

Примеры в архиве не заменяют официальную документацию. Проверяйте схему своей установленной версии OpenCode.
