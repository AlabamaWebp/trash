import fs from "node:fs";

const file = process.argv[2] || "opencode.json";
if (!fs.existsSync(file)) {
  console.error("File not found:", file);
  process.exit(2);
}

let config;
try {
  config = JSON.parse(fs.readFileSync(file, "utf8"));
} catch {
  console.error("This audit accepts JSON only, not JSONC.");
  process.exit(2);
}

const servers = Object.keys(config.mcp?.servers || {});
console.log("Configured project MCP servers:", servers.length);
for (const name of servers) console.log("-", name);
if (servers.length > 3) {
  console.log("Consider disabling servers not needed for this task.");
}
console.log("Global MCP configuration must be reviewed separately.");
