import { spawnSync } from "node:child_process";

const query = process.argv[2];
const target = process.argv[3] || "src";
const limit = Math.min(200, Math.max(1, Number(process.env.MAX_HITS || 50)));

if (!query) {
  console.error("Usage: node search.mjs <literal-query> [directory]");
  process.exit(2);
}

const args = [
  "--line-number", "--no-heading", "--color", "never",
  "--fixed-strings", "--max-columns", "240",
  "--max-columns-preview", "--max-count", "20",
  "--glob", "*.{ts,tsx,html,scss,css,json}",
  "--glob", "!**/node_modules/**",
  "--glob", "!**/dist/**",
  query, target
];

const result = spawnSync("rg", args, {
  encoding: "utf8",
  maxBuffer: 8 * 1024 * 1024
});

if (result.error) {
  console.error("Cannot start rg:", result.error.message);
  process.exit(2);
}
if (result.status > 1) {
  console.error(result.stderr || "rg failed");
  process.exit(result.status);
}

const lines = (result.stdout || "").split(/\r?\n/).filter(Boolean);
console.log(lines.length ? lines.slice(0, limit).join("\n") : "No matches");
if (lines.length > limit) console.log("... output truncated");
