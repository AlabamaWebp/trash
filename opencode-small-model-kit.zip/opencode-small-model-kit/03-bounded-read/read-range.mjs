import fs from "node:fs";
import path from "node:path";

const file = process.argv[2];
const start = Number(process.argv[3] || 1);
const count = Number(process.argv[4] || 60);

if (!file || !Number.isInteger(start) || start < 1 ||
    !Number.isInteger(count) || count < 1) {
  console.error("Usage: node read-range.mjs <file> [start>=1] [count>=1]");
  process.exit(2);
}

const root = fs.realpathSync(process.cwd());
const resolved = fs.realpathSync(path.resolve(file));
const relative = path.relative(root, resolved);

if (relative.startsWith("..") || path.isAbsolute(relative) ||
    relative.split(path.sep).some(x => x === "node_modules" || x === ".git")) {
  console.error("Reading outside project or excluded directory is forbidden");
  process.exit(2);
}

const lines = fs.readFileSync(resolved, "utf8").split(/\r?\n/);
const end = Math.min(lines.length, start - 1 + Math.min(count, 120));
for (let i = start - 1; i < end; i++) {
  const line = lines[i].length > 500
    ? lines[i].slice(0, 500) + " ...[truncated]"
    : lines[i];
  console.log(String(i + 1).padStart(5) + " | " + line);
}
