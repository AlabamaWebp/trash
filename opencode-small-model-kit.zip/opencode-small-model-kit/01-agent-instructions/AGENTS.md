# Efficient Coding Rules

- Work on one logical change at a time.
- First locate files with glob or grep. Do not read entire directories.
- Read only relevant file ranges. Expand only if needed.
- For TypeScript, identify declarations, imports and call sites before editing.
- Keep changes minimal. Preserve unrelated code and public APIs.
- Do not repeat a failed command without changing the approach.
- Do not paste complete build logs into the conversation.
- Run the smallest relevant verification after editing.
- If blocked, report the exact blocker and next action.
- Never claim verification that was not actually run.
- Keep the final response short: changed files, checks, remaining risks.
