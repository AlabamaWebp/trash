import fs from "node:fs";
import { spawnSync } from "node:child_process";
import ts from "typescript";

const query = (process.argv[2] || "").toLowerCase();
const target = process.argv[3] || "src";

if (!query) {
  console.error("Usage: node symbols.mjs <symbol-substring> [directory]");
  process.exit(2);
}

const scan = spawnSync("rg", [
  "--files", "--glob", "*.ts",
  "--glob", "!*.d.ts", "--glob", "!**/node_modules/**",
  target
], { encoding: "utf8", maxBuffer: 8 * 1024 * 1024 });

if (scan.error || scan.status > 1) {
  console.error(scan.error?.message || scan.stderr);
  process.exit(2);
}

const paths = scan.stdout.split(/\r?\n/).filter(Boolean).slice(0, 1000);
let shown = 0;

for (const file of paths) {
  const source = ts.createSourceFile(
    file, fs.readFileSync(file, "utf8"),
    ts.ScriptTarget.Latest, true
  );

  function visit(node) {
    const supported =
      ts.isClassDeclaration(node) ||
      ts.isInterfaceDeclaration(node) ||
      ts.isTypeAliasDeclaration(node) ||
      ts.isFunctionDeclaration(node) ||
      ts.isMethodDeclaration(node) ||
      ts.isEnumDeclaration(node);

    if (supported && node.name) {
      const name = node.name.getText(source);
      if (name.toLowerCase().includes(query) && shown < 60) {
        const line = source.getLineAndCharacterOfPosition(
          node.getStart(source)
        ).line + 1;
        console.log(file + ":" + line + " " +
          ts.SyntaxKind[node.kind] + " " + name);
        shown++;
      }
    }
    if (shown < 60) ts.forEachChild(node, visit);
  }
  visit(source);
  if (shown >= 60) break;
}

if (!shown) console.log("No matching declarations");
if (shown >= 60) console.log("... result limit reached");
