import fs from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";

let args = process.argv.slice(2);
if (args[0] === "--") args.shift();
if (!args.length) {
  console.error("Usage: node compact-run.mjs -- <command> [args...]");
  process.exit(2);
}

const dir = path.join(".agent", "logs");
fs.mkdirSync(dir, { recursive: true });
const stamp = new Date().toISOString().replace(/[:.]/g, "-");
const logPath = path.join(dir, "run-" + stamp + "-" + process.pid + ".log");
const log = fs.createWriteStream(logPath);

const command = process.platform === "win32" && args[0] === "npx"
  ? "npx.cmd" : args[0];
const child = spawn(command, args.slice(1), {
  shell: false, stdio: ["inherit", "pipe", "pipe"]
});

const pattern = /\berror\b|\bfailed\b|exception|TS\d{4,5}|NG\d{4,5}/i;
const output = [];
const before = [];
let after = 0;
const maxLines = 80;

function push(line) {
  if (output.length < maxLines) output.push(line.slice(0, 500));
}
function handleLine(line) {
  const hit = pattern.test(line);
  if (hit) {
    for (const prev of before) push(prev);
    after = 2;
  }
  if (hit || after > 0) {
    push(line);
    if (!hit) after--;
  }
  before.push(line);
  if (before.length > 2) before.shift();
}
function attach(stream) {
  let pending = "";
  stream.on("data", chunk => {
    log.write(chunk);
    pending += chunk.toString("utf8");
    const lines = pending.split(/\r?\n/);
    pending = lines.pop() || "";
    for (const line of lines) handleLine(line);
    if (pending.length > 100000) {
      handleLine(pending.slice(0, 500));
      pending = "";
    }
  });
  stream.on("end", () => {
    if (pending) handleLine(pending);
  });
}
attach(child.stdout);
attach(child.stderr);

child.on("error", error => {
  console.error("Command failed to start:", error.message);
  log.end();
  process.exitCode = 127;
});
child.on("close", code => {
  log.end();
  console.log(output.length ? output.join("\n") : "(no error lines selected)");
  if (output.length >= maxLines) console.log("... diagnostic output capped");
  console.log("Exit code:", code ?? 127);
  console.log("Full log:", logPath);
  process.exitCode = code ?? 127;
});
