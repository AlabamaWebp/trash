export class UserCardComponent {
  readonly title = "User";
  formatName(first: string, last: string): string {
    return first.trim() + " " + last.trim();
  }
}
