import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const dirs = fs.readdirSync(root).filter(x => /^\d\d-/.test(x));
const missing = dirs.filter(x =>
  !fs.existsSync(path.join(root, x, "README.md"))
);

console.log("Practices:", dirs.length);
if (dirs.length !== 14 || missing.length) {
  console.error("Incomplete kit:", missing.join(", "));
  process.exitCode = 1;
} else {
  console.log("PASS: 14 practices with README.md");
}
