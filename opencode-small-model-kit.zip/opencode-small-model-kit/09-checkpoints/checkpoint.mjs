import fs from "node:fs";
import path from "node:path";

const file = path.join(".agent", "state.json");
const [action, ...parts] = process.argv.slice(2);
const value = parts.join(" ").slice(0, 1000);

function save(state) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  state.updatedAt = new Date().toISOString();
  const temp = file + "." + process.pid + ".tmp";
  fs.writeFileSync(temp, JSON.stringify(state, null, 2) + "\n");
  fs.renameSync(temp, file);
}
function load() {
  if (!fs.existsSync(file)) {
    console.error("State not found. Run: node checkpoint.mjs init <goal>");
    process.exit(2);
  }
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

if (action === "init") {
  if (!value) {
    console.error("Usage: checkpoint.mjs init <goal>");
    process.exit(2);
  }
  if (fs.existsSync(file)) {
    console.error("State already exists; not overwriting.");
    process.exit(2);
  }
  save({ objective: value, next: "Locate relevant code",
    completed: [], verification: [], updatedAt: "" });
} else if (action === "show") {
  console.log(JSON.stringify(load(), null, 2));
} else if (["next", "done", "verify"].includes(action) && value) {
  const state = load();
  if (action === "next") state.next = value;
  if (action === "done") state.completed.push(value);
  if (action === "verify") state.verification.push(value);
  state.completed = state.completed.slice(-30);
  state.verification = state.verification.slice(-15);
  save(state);
} else {
  console.error("Usage: checkpoint.mjs init|show|next|done|verify [text]");
  process.exit(2);
}
