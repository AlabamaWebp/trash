# Структурированные checkpoint между сессиями

**Сложность:** Средняя

## Что решает

Хранит цель, следующую операцию, выполненные действия и результаты проверок вне контекстного окна модели.

## Установка

Скопируйте checkpoint.mjs в scripts/checkpoint.mjs. Создайте состояние командой init. При необходимости добавьте .agent/state.json в Git.

## Пример использования

~~~sh
node scripts/checkpoint.mjs init "Исправить типизацию UserService"
node scripts/checkpoint.mjs next "Найти декларацию UserService"
node scripts/checkpoint.mjs done "Нашёл исходный файл"
node scripts/checkpoint.mjs verify "tsc --noEmit: PASS"
node scripts/checkpoint.mjs show
~~~

## Ожидаемый результат

Файл .agent/state.json обновляется атомарной заменой и может быть прочитан агентом в новой сессии.

## Ограничения

Состояние обновляется явными командами, а не автоматически. Не записывайте в него секреты и длинные логи.

Все пути в командах указаны относительно корня вашего Angular/TypeScript-проекта. Примеры предназначены для OpenCode V2; перед переносом конфигураций объедините их с существующим opencode.jsonc.
