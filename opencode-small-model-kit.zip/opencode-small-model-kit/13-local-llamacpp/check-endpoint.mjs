const url = process.argv[2] || "http://127.0.0.1:8080/v1/models";
try {
  const response = await fetch(url, {
    signal: AbortSignal.timeout(5000)
  });
  if (!response.ok) throw new Error("HTTP " + response.status);
  const body = await response.json();
  const ids = (body.data || []).map(x => x.id);
  console.log("Available model IDs:");
  for (const id of ids) console.log("-", id);
  if (!ids.length) console.log("No model IDs returned");
} catch (error) {
  console.error("Endpoint check failed:", error.message);
  process.exitCode = 1;
}
