# Verification gate для Angular/TypeScript

**Сложность:** Низкая

## Что решает

Проверяет типизацию после изменений и запускает существующий lint-скрипт, если он объявлен в package.json.

## Установка

Скопируйте verify.mjs в scripts/verify.mjs.

## Пример использования

~~~sh
node scripts/verify.mjs
~~~

## Ожидаемый результат

Вывод PASS или FAIL и код завершения. При ошибке TypeScript проверка останавливается.

## Ограничения

Это базовая проверка. Она не заменяет Angular template compilation и unit/e2e тесты. Для полного Angular build добавьте отдельный этап npm run build.

Все пути в командах указаны относительно корня вашего Angular/TypeScript-проекта. Примеры предназначены для OpenCode V2; перед переносом конфигураций объедините их с существующим opencode.jsonc.
