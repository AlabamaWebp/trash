import fs from "node:fs";
import { spawnSync } from "node:child_process";

const npx = process.platform === "win32" ? "npx.cmd" : "npx";
const npm = process.platform === "win32" ? "npm.cmd" : "npm";
const tsconfig = fs.existsSync("tsconfig.app.json")
  ? "tsconfig.app.json"
  : fs.existsSync("tsconfig.json") ? "tsconfig.json" : null;

if (!tsconfig) {
  console.error("No tsconfig.app.json or tsconfig.json found");
  process.exit(2);
}

function run(command, args) {
  console.log("Running:", command, args.join(" "));
  const result = spawnSync(command, args, { stdio: "inherit" });
  if (result.error) {
    console.error(result.error.message);
    process.exit(2);
  }
  if (result.status !== 0) {
    console.error("FAIL:", result.status);
    process.exit(result.status || 1);
  }
}

run(npx, ["tsc", "--noEmit", "-p", tsconfig]);

if (fs.existsSync("package.json")) {
  const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));
  if (pkg.scripts && pkg.scripts.lint) run(npm, ["run", "lint"]);
}

console.log("PASS: TypeScript and available lint checks");
